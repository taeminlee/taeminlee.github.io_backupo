---
title: "Layout: More Tag"
categories:
  - Layout
  - Uncategorized
tags:
  - content
  - read more
  - layout
---

This content is before the [excerpt separator tag](http://jekyllrb.com/docs/posts/#post-excerpts).

Right after this sentence there should be a **continue reading** link of some sort in archive-index pages.

<!--more-->

And this content is after the more tag.